<?php

$info = array();
$info['plugin-name'] = 'fresh-favicon';
$info['plugin-version'] = '1.1.1';