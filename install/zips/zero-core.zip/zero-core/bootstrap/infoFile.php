<?php
/*
 * MUST contain $pluginInfo['mainClassName'], this way is to tell the framework
* which class it should create
*/
$pluginInfo['mainClassName'] = 'ffPluginZeroCore';