<?php

$info = array();
$info['plugin-name'] = 'zero-core';
$info['plugin-version'] = '1.0.0';