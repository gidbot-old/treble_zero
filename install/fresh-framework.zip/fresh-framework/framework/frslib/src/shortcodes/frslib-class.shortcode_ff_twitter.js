"use strict";

(function($){

	frslib.provide('frslib._classes.shortcodes');
	frslib.provide('frslib._instances.shortcodes');

	frslib._classes.shortcodes.ff_twitter = function() {

//##############################################################################
//# INHERITANCE
//##############################################################################


		// itself
		var _ = frslib._classes.shortcodes._shortcode_ff_abstract();


//##############################################################################
//# EXECUTIVE FUNCTIONS Swap to HTML, Swap to Text
//##############################################################################




//##############################################################################
//# RETURN ITSELF;
//##############################################################################


		return _;


	};


})(jQuery);
