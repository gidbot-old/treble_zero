<?php

class ffLib_TwitterFeeder_OneTweet extends ffBasicObject {
	public $date = null;
	public $id = null;
	public $text = null;
    public $textWithLinks = null;
	public $source = null;
	public $profileImage = null;
	public $profileName = null;
	public $profileScreenName = null;
}