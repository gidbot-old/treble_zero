<?php
class ffPluginInstallerGeneral extends ffBasicObject {

}