<?php
interface ffIOneDataNode {
	public function getId();
}