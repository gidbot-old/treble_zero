<?php

class ffTaxUpdater extends ffBasicObject{

}